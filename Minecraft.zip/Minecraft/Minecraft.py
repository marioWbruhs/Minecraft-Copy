import pygame
import os
import numpy as np
import time

tt=time.time()
'''

id:
{
	0-grass
	1-dirt
	2-stone
	3-coal
	4-iron
	5-oak
	6-leave
}

'''

os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (250,100)

def loadImage(x,y,name):
	
	image=pygame.image.load(name)
	win.blit(image,[x,y])


def text(fs,text,color,x,y):
	font = pygame.font.Font('freesansbold.ttf', fs) 
	text = font.render(text, True, color) 
	win.blit(text,[x,y])


class Player:
	def __init__(self,x,y):
		self.x=x
		self.y=y


	def draw(self):
		pygame.draw.rect(win,(0,0,0),[self.x,self.y,16,32])


	




class terrainGenerator:
	def PerlinNoise(x,amp):
		return x+np.random.randint(-1,2)*amp


	def generateTerrain(px,py):
		
		pos=[]
		a=0
		prevpos=np.random.randint(100,500)
		while prevpos%16!=0:
			prevpos=np.random.randint(100,500)
		for x in range(-px,px+496*3,16):
			a+=1
			cy=terrainGenerator.PerlinNoise(prevpos,16)
			pos.append([x+px,cy+py,0])
			pos.append([x+px,cy+16+py,1])
			if np.random.uniform(0.0,3.0)<=.5:
				pos.append([x+px,cy-16+py,5])
				pos.append([x+px,cy-32+py,5])
				pos.append([x+px,cy-48+py,5])
				#pos.append([x,cy-64,5])
				pos.append([x-32+px,cy-64+py,6])
				pos.append([x-16+px,cy-64+py,6])
				pos.append([x+32+px,cy-64+py,6])
				pos.append([x+16+px,cy-64+py,6])
				pos.append([x+px,cy-64+py,6])
				pos.append([x-16+px,cy-80+py,6])
				pos.append([x+16+px,cy-80+py,6])
				pos.append([x+px,cy-80+py,6])
				pos.append([x+px,cy-96+py,6])

			prevpos=cy
			for y in range(prevpos+32,496,16):
				pos.append([x+px,y+py,2])
				if np.random.uniform(0.00,2.00)<=0.05:
					pos.append([x+px,y+py,3])
				if np.random.uniform(0.00,2.00)<=0.02:
					pos.append([x+px,y+py,4])
				pos.append([x+px,y+py,7])
		return pos


	def draw(pos):
		#pos=generateTerrain()
		yy=-(y-pos[0][1]+32)
		for i in range(len(pos)):
			if pos[i][0]>=x-32 and pos[i][0]<=x+592 and pos[i][1]>=0 and pos[i][1]<=496:
				pos[i][0]=round16(pos[i][0])
				if pos[i][2]==0:
					loadImage(pos[i][0]-x,pos[i][1],'grass.png')
					#pygame.draw.rect(win,(69, 179, 57),[pos[i][0]-x,pos[i][1]+yy,16,16])
				if pos[i][2]==1:
					loadImage(pos[i][0]-x,pos[i][1],'dirt.png')

					#pygame.draw.rect(win,(94, 57, 2),[pos[i][0]-x,pos[i][1]+yy,16,16])
				if pos[i][2]==2:
					loadImage(pos[i][0]-x,pos[i][1],'stone.png')

					#pygame.draw.rect(win,(96, 102, 115),[pos[i][0]-x,pos[i][1]+yy,16,16])
				if pos[i][2]==3:
					loadImage(pos[i][0]-x,pos[i][1],'coalore.png')

					#pygame.draw.rect(win,(52, 53, 56),[pos[i][0]-x,pos[i][1]+yy,16,16])
				if pos[i][2]==4:
					loadImage(pos[i][0]-x,pos[i][1],'ironore.png')

					#pygame.draw.rect(win,(255, 176, 120),[pos[i][0]-x,pos[i][1]+yy,16,16])
				if pos[i][2]==5:
					loadImage(pos[i][0]-x,pos[i][1],'oaklog.png')

					#pygame.draw.rect(win,(189, 97, 0),[pos[i][0]-x,pos[i][1]+yy,16,16])#8, 204, 51
				if pos[i][2]==6:
					loadImage(pos[i][0]-x,pos[i][1],'leaf.png')
				if pos[i][2]==7:
					loadImage(pos[i][0]-x,pos[i][1],'bedrock.png')
					#pygame.draw.rect(win,(8, 204, 51),[pos[i][0]-x,pos[i][1]+yy,16,16])



pygame.init()

x=0
y=0
vel=0
speed=2
jump=False
clock = pygame.time.Clock()
hitboxes=[]
bsid=['grass','dirt','stone','coal','iron','oaklog','leaf',]
bid=0

win=pygame.display.set_mode((596,496))

pygame.mouse.set_pos((390-6,280+16))

pos=terrainGenerator.generateTerrain(x,y)

y=280+16#280+16pos[0][1]-32


def events():
	for e in pygame.event.get():
		if e.type==pygame.QUIT:
			quit()


def redrawWin(x,y):
	win.fill((88, 240, 245))
	events()
	
	terrainGenerator.draw(pos)

	# for i in range(len(pos)):
	# 	pygame.draw.rect(win,(0,0,0),[pos[i][0],pos[i][1],16,16],1)

	#text(20,f'Done in just {ct-tt} seconds',(0,0,0),0,0)
	nt=time.time()
	text(20,f'x: {x/16+0.5}',(0,0,0),0,20)
	text(20,f'y: {63-y/16}',(0,0,0),0,40)
	text(20,f'time played: {int(nt-tt)}',(0,0,0),0,60)
	text(20,f'FPS: {int(clock.get_fps())}',(0,0,0),0,80)

	for i in range(0,len(bsid)):
		if not i==bid:
			text(20,f'{bsid[i]}',(0,0,0),i*60,0)
		else:
			text(20,f'{bsid[i]}',(255,0,0),i*60,0)
	p=Player(390-6,y)
	p.draw()
	if x/16>=110:
		#print(12312dddddddddddddddddddd)
		text(25,f'DISTANCE TO BORDER:{118-x/16}',(0,0,0),100,200)
	if x<=10:
		text(25,f'DISTANCE TO BORDER:{x/16-0}',(0,0,0),100,200)

	pygame.display.flip()#pygame.display.update()

	
ct=time.time()

flying=False

print(f'Done in just {ct-tt}')

#stop=pos[0][1]

def round16(x):
	if not x%16==0:
		#print(12)
		return x-x%16
	else:
		#print(32)
		return x

while True:
	key=pygame.key.get_pressed()
	
	
	if key[pygame.K_d]:
		x+=speed
	if key[pygame.K_a]:
		x-=speed
	if key[pygame.K_LCTRL]:
		speed=4
	else:
		speed=2
	if key[pygame.K_SPACE]:
		y-=1
	if key[pygame.K_LSHIFT]:
		y+=1
	if jump:
		vel-=1
	if x/16>=118:
		x-=speed
	if x/16<=0:
		x+=speed
	if key[pygame.K_1]:
		bid=0
	if key[pygame.K_2]:
		bid=1
	if key[pygame.K_3]:
		bid=2
	if key[pygame.K_4]:
		bid=3
	if key[pygame.K_5]:
		bid=4
	if key[pygame.K_6]:
		bid=5
	
	MOUSEPRESSED=pygame.mouse.get_pressed()
	MOUSEPOS=pygame.mouse.get_pos()
	if 1 in MOUSEPRESSED:
		for i in range(0,len(pos)-1):
			if MOUSEPOS[0]+x>=pos[i][0] and MOUSEPOS[1]>=pos[i][1] and MOUSEPOS[0]+x<=pos[i][0]+16 and MOUSEPOS[1]<=pos[i][1]+16:
				if MOUSEPRESSED[0]:
					del pos[i]
					break
	if MOUSEPRESSED[2]:
		pos.append([round16(MOUSEPOS[0]+x),round16(MOUSEPOS[1]),bid])
	#y-=vel
	clock.tick(60)
	redrawWin(x,y)

