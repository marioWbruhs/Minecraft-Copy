import pygame

pygame.init()

s=pygame.display.set_mode((600,600))

while True:
	s.fill(0)
	for e in pygame.event.get():
		if e.type==pygame.QUIT:
			quit()
	pygame.draw.rect(s,(255,0,0),[100,100,20,20])
	p=[100,100]
	#pygame.draw.rect(s,(0,255,0),[p[0],p[1],p[0]+20,p[1]+20])
	pygame.draw.line(s,(255,255,255),[])
	pygame.display.update()